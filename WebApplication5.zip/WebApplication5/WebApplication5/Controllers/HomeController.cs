﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security.Claims;
using System.Security.Cryptography.Xml;
using System.Text.Unicode;
using System.Text;
using WebApplication5.Data;
using WebApplication5.Models;
using static System.Net.Mime.MediaTypeNames;

namespace WebApplication5.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        //private readonly ILogger<HomeController> _logger;

        //public HomeController(ILogger<HomeController> logger)
        //{
        //    _logger = logger;
        //}
        private readonly AppConn _conn;

        public object HttpContextSession { get; private set; }

        public HomeController (AppConn conn)
        {
            _conn = conn;
        }

        public IActionResult Index()
        {
            HttpClient client = new HttpClient();
            var data = client.GetAsync("http://localhost:5174/api/Demo/Emptbl").Result; //2 step
            var readdata = data.Content.ReadAsStringAsync().Result;
            var v = JsonConvert.DeserializeObject<List<EmpModel>>(readdata);
            return View(v);
            //var res = _conn.Emp.ToList();
            //return View(res);
        }
        [HttpGet]
        public IActionResult Create()
        {
           
            return View();
          
        }
        [HttpPost]
        public IActionResult Create(EmpModel obj)
        {
            HttpClient client = new HttpClient();
            var data = JsonConvert.SerializeObject(obj);
            //StringContent postdata = new StringContent(data, System.Text.Encoding.UTF8, "application/json");
            StringContent postdata = new StringContent(data, System.Text.Encoding.UTF8, "application/json");
            var res = client.PostAsync("http://localhost:5174/api/Create" + "?Name=" + obj.Name + "&Email=" + obj.Email + "&Password=" + obj.Password + "&Mobile=" + obj.Mobile + "&Dob=" + obj.Dob + "&Adhar" + obj.Adhar + "&Address" + obj.Address,postdata).Result;
        
            return RedirectToAction("Index");
            //if(obj.Id== 0)
            // {
            //     _conn.Emp.Add(obj);
            //     _conn.SaveChanges();
            // }
            // else
            // {
            //     _conn.Entry(obj).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            //     _conn.SaveChanges() ;
            // }
           // return RedirectToAction("Index");
        }
        public IActionResult Update(int Id)
        {
            //http://localhost:5174/Api/UpdateEmp?Id=33
            //var res = _conn.Emp.Where(a => a.Id == Id).First();
            //return View("Create",res);

            HttpClient client = new HttpClient();

            var res = client.GetAsync("http://localhost:5174/Api/UpdateEmp"+ "?Id"+Id).Result;
            var readdata = res.Content.ReadAsStringAsync().Result;
            var data = JsonConvert.DeserializeObject<EmpModel>(readdata);
            return View("Create",data);
        }
        public IActionResult Delete(int Id)
        {
            //HttpClient client = new HttpClient();

            //var res = client.GetAsync("http://localhost:5174/api/demo/DelEmp" + "?Id=" + Id).Result;
        
           // return RedirectToAction("Index");
            var res = _conn.Emp.Where(a=>a.Id==Id).FirstOrDefault();
            _conn.Emp.Remove(res);
           _conn.SaveChanges();

            return RedirectToAction("Index");
        }

        public IActionResult Logtbl()
        {
            var res=_conn.Login.ToList();
            return View(res);
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult CreateAcc()
        {
            return View();
        }
        [HttpPost]
        [AllowAnonymous]
        public IActionResult CreateAcc(LoginModel obj)
        {
            if (obj.Id == 0)
            {
                _conn.Login.Add(obj);
                _conn.SaveChanges();
            }
            else
            {
                _conn.Entry(obj).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                _conn.SaveChanges();
            }
            return RedirectToAction("Logtbl");
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult Login()
        {
            return View();
        }

        public object GetHttpContextSession()
        {
            return HttpContextSession;
        }

        [HttpPost]
        [AllowAnonymous]
        public IActionResult Login(LoginModel obj, object httpContextSession)
        {
            var res = _conn.Login.Where(a => a.Email == obj.Email).FirstOrDefault();
        HttpContext.Session.SetString("Name", "Welcome:"+res.Name);
            var v = HttpContext.Session.GetString("Name");

            if (res == null)
            {
                TempData["Email"] = "Wrong Email-Address Please Check Email ";
            }
            else
            {
                if(res.Email.ToLower()==obj.Email.ToLower() && res.Password == obj.Password)
                {
                    var claims = new[] {new Claim(ClaimTypes.Name,res.Name),
                    new Claim (ClaimTypes.Email,res.Email)};

                    var identity=new ClaimsIdentity(claims,
                       CookieAuthenticationDefaults.AuthenticationScheme);
                    var authPropeties=new AuthenticationProperties
                    {
                        IsPersistent=true
                    };
                     HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,
                        new ClaimsPrincipal(identity),
                        authPropeties);
                    return RedirectToAction("Index");
                }
                else
                {
                    TempData["Password"] = "Wrong Password Please Check Password ";
                }
            }
           return View();
        }
        public IActionResult Logout( )
        {
            HttpContext.SignOutAsync();
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult Forgat()
        {
            return View();
        }
        
        public IActionResult ForgatPasss(string Email)
        {
            var res=_conn.Login.Where(a => a.Email == Email).FirstOrDefault();
            return View(res);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
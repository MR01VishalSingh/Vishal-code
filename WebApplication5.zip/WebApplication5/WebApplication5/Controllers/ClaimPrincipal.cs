﻿using System.Security.Claims;

namespace WebApplication5.Controllers
{
    internal class ClaimPrincipal
    {
        private ClaimsIdentity identity;

        public ClaimPrincipal(ClaimsIdentity identity)
        {
            this.identity = identity;
        }
    }
}
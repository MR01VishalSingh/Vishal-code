﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication5.Models
{
    public class EmpModel
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string? Name { get; set; }
        [Required]
        [EmailAddress]
        public string? Email { get; set; }
        [Required]
        public string? Password { get; set; }
        [MaxLength(20)]
        public string? Mobile { get; set; }
        public DateTime Dob { get; set; }
        [Required]
        [MaxLength(12)]
        public string? Adhar { get; set; }
        public string? Address { get; set; }
    }
}

﻿
using Microsoft.EntityFrameworkCore;
using WebApplication5.Models;

namespace WebApplication5.Data
{
    public class AppConn:DbContext
    {
        public AppConn(DbContextOptions<AppConn>options) :base (options){ }
        public DbSet<EmpModel> Emp { get; set; }
        public DbSet<LoginModel> Login { get; set; }
 
    }
}

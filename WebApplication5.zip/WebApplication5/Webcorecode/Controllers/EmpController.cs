﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Webcorecode.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HomeController : ControllerBase
    {
      
        public List<string> Get()
        {
            List<string> list = new List<string>()
            {
                "Vishal","Amit","Sumit"
            };
            return list;
        }
    }
}

﻿using Microsoft.EntityFrameworkCore;
using Webcorecode.Model;

namespace Webcorecode.Data
{
    public class Appconn:DbContext
    {
        public Appconn(DbContextOptions<Appconn> options) : base(options) { }
        public DbSet<EmpModel> Emp { get; set; }
        public DbSet<LoginModel> Login { get; set; }

    }
}
